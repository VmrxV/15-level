﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _15._2
{
	public partial class Form1 : Form
	{
		public Graphics g;     // холст
		const int N_max = 50;  // максимальное число шаров
		public Sharik[] shar = new Sharik[N_max];
		// объявление объектов - массив шаров
		public int N = 10;   // фактическое число шаров
		Random r = new Random();    // случайное число
		SolidBrush brf;
		public Form1()
		{
			InitializeComponent();
			this.BackColor = Color.Green; // цвет сукна
			this.Width = 1350; // новая ширина стола
			this.Height = 700; // новая длина стола
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			g = CreateGraphics();  // объект - на форме
		}

		private void Form1_Click(object sender, EventArgs e)
		{
			N = Convert.ToInt32(comboBox1.Text);
			int rch;
			for (int i = 0; i < N; i++)
			{
				rch = r.Next(100000);
				shar[i] = new Sharik(rch);
			}
			timer1.Enabled = true;  // запуск таймера
			g.Clear(BackColor);   // очистка поля от шаров
			brf = new SolidBrush(BackColor);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			Sharik s;  // ссылка на объект класса Sharik
			for (int i = 0; i < N; i++)
			{
				s = shar[i];
				// очистка холста от ранее нарисованного шара
				g.FillEllipse(brf, s.x, s.y, 2 * s.radius, 2 * s.radius);
				s.Next();  // его новое расположение через сдвиг
						   // изображение i-го шара после сдвига
				g.FillEllipse(s.br, s.x + 2, s.y + 2, 2 * s.radius - 4, 2 * s.radius - 4);
			}
		}

		private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
		{
			N = Convert.ToInt32(comboBox1.Text);
			comboBox1.Visible = false;
			label1.Visible = false;
			Form1_Click(sender, e);
		}
	}
	public class Sharik :Form1
	{
		public int radius;      // радиус
		public SolidBrush br;   // кисть для его рисования
		public int x;           // координата x - слева
		public int y;           // координата y - сверху
		int dx;                 // шаг смещения по x
		int dy;                 // шаг смещения по y
								// задание свойств шара
		public Sharik(int rch)
		{
			Random r = new Random(rch); // для новой цепочки 
										//   случайных чисел через rch
			br = new SolidBrush(RandomColor(rch));
			radius = r.Next(30, 50);
			x = r.Next(1, ClientRectangle.Width - 2 * radius);
			y = r.Next(1, ClientRectangle.Height - 2 * radius);
			dx = r.Next(2, 6);
			dy = r.Next(3, 5);
		}
		// отражение от стенок бильярда
		public void Next()
		{
			if (x >= Form1.ActiveForm.Width - 2 * radius)
				dx = -dx;
			if (x <= 0)
				dx = -dx;
			x += dx;
			if (y >= Form1.ActiveForm.Height - 2 * radius)
				dy = -dy;
			if (y <= 0)
				dy = -dy;
			y += dy;
		}
		// случайный цвет
		public Color RandomColor(int rch)      // rch - случайное число
		{
			int r, g, b;
			byte[] bytes1 = new byte[3];        // массив 3 цветов
			Random rnd1 = new Random(rch);
			rnd1.NextBytes(bytes1);             // генерация в массив 
			r = Convert.ToInt16(bytes1[0]);
			g = Convert.ToInt16(bytes1[1]);
			b = Convert.ToInt16(bytes1[2]);
			return Color.FromArgb(r, g, b);     // возврат цвета 
		}

		
	}
}
