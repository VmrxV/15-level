﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _15._1
{
	public partial class Form1 : Form
	{
		public Sharik shar;
		Graphics g;
		SolidBrush brf;
		public Form1()
		{
			InitializeComponent();
			this.BackColor = Color.Green;
			brf = new SolidBrush(BackColor);
			this.Width = 1000;
			this.Height = 500;
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			g = this.CreateGraphics();
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			g.FillEllipse(brf, shar.x, shar.y, 2 * shar.radius, 2 * shar.radius);
			shar.Next();
			g.FillEllipse(shar.br, shar.x, shar.y, 2 * shar.radius, 2 * shar.radius);
		}
		private void Form1_Click(object sender, EventArgs e)
		{
			shar = new Sharik(50, Color.Yellow, 5, 150, 6,- 5);
			timer1.Enabled = true;
		}
		public class Sharik : Form1
		{

			public int radius;       // радиус 
			public SolidBrush br;
			public int x;            // координата x — левая граница шара
			public int y;            // координата y — граница шара сверху
			int dx;
			int dy;


			public  Sharik(int r, Color c, int x0, int y0, int d_x, int d_y)
			{
				radius = r;
				br = new SolidBrush(c);
				x = x0;
				y = y0;
				dx = d_x;
				dy = d_y;
			}
		public void Next()
		{
				if (x >= Form1.ActiveForm.Width - 2 * radius)
					dx = -dx;
				if (x < 0)
					dx = -dx;
				x += dx;
				if (y >= Form1.ActiveForm.Height - 2 * radius)
					dy = -dy;
				if (y < 0)
					dy = -dy;
				y += dy;
		}
	}

	}
}
